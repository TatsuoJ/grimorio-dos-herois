import React, { useState, useEffect, useCallback } from 'react';
import './App.css';

function App() {
  const [nome, setNome] = useState('');
  const [classe, setClasse] = useState('');
  const [raca, setRaca] = useState('');
  const [nivel, setNivel] = useState(1);
  const [historia, setHistoria] = useState('');
  const [personagens, setPersonagens] = useState([]);
  const [mensagem, setMensagem] = useState({ texto: '', tipo: '' });
  const [editingId, setEditingId] = useState(null);
  const [busca, setBusca] = useState('');
  const [loading, setLoading] = useState(false);
  const [showMagicEffect, setShowMagicEffect] = useState(false);

  const API_URL = 'http://localhost:3000/personagens';

  const classes = [
    'Guerreiro', 'Mago', 'Arqueiro', 'Ladino', 
    'Paladino', 'Necromante', 'Bárbaro', 'Clérigo',
    'Druida', 'Bardo', 'Monge', 'Feiticeiro'
  ];

  const racas = [
    'Humano', 'Elfo', 'Anão', 'Orc', 
    'Meio-Elfo', 'Halfling', 'Tiefling', 'Drow',
    'Gnomo', 'Draconato', 'Meio-Orc', 'Goblin'
  ];

  const fetchPersonagens = useCallback(async () => {
    try {
      setLoading(true);
      const url = busca ? `${API_URL}?busca=${encodeURIComponent(busca)}` : API_URL;
      const response = await fetch(url);
      if (!response.ok) throw new Error('Falha ao buscar personagens.');
      const data = await response.json();
      setPersonagens(data);
    } catch (err) {
      setMensagem({ texto: 'Erro ao carregar personagens: ' + err.message, tipo: 'erro' });
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [busca, API_URL]);

  useEffect(() => {
    fetchPersonagens();
  }, [fetchPersonagens]);

  useEffect(() => {
    if (mensagem.texto) {
      const timer = setTimeout(() => {
        setMensagem({ texto: '', tipo: '' });
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [mensagem]);

  const resetForm = () => {
    setNome('');
    setClasse('');
    setRaca('');
    setNivel(1);
    setHistoria('');
    setEditingId(null);
  };

  const triggerMagicEffect = () => {
    setShowMagicEffect(true);
    setTimeout(() => setShowMagicEffect(false), 3000);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMensagem({ texto: '', tipo: '' });

    if (!nome || !classe || !raca) {
      setMensagem({ texto: 'Nome, Classe e Raça são obrigatórios.', tipo: 'erro' });
      return;
    }

    const personagemPayload = { nome, classe, raca, nivel, historia };

    try {
      setLoading(true);
      triggerMagicEffect();
      
      let response;
      if (editingId) {
        response = await fetch(`${API_URL}/${editingId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(personagemPayload),
        });
      } else {
        response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(personagemPayload),
        });
      }

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Operação falhou.');

      if (editingId) {
        setMensagem({ texto: `${nome} foi atualizado no grimório com sucesso.`, tipo: 'sucesso' });
      } else {
        setMensagem({ texto: `${data.nome} foi registrado no grimório com sucesso.`, tipo: 'sucesso' });
      }

      resetForm();
      fetchPersonagens();
    } catch (err) {
      setMensagem({ texto: err.message, tipo: 'erro' });
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (personagemId, personagemNome) => {
    if (!window.confirm(`Deseja realmente remover ${personagemNome} do grimório?`)) return;

    setMensagem({ texto: '', tipo: '' });

    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/${personagemId}`, { method: 'DELETE' });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Erro ao deletar personagem.');

      setMensagem({
        texto: `${personagemNome} foi removido do grimório.`,
        tipo: 'sucesso'
      });

      if (editingId === personagemId) resetForm();
      fetchPersonagens();
    } catch (err) {
      setMensagem({ texto: err.message, tipo: 'erro' });
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (personagem) => {
    setNome(personagem.nome || '');
    setClasse(personagem.classe || '');
    setRaca(personagem.raca || '');
    setNivel(personagem.nivel || 1);
    setHistoria(personagem.historia || '');
    setEditingId(personagem.id);
    setMensagem({ texto: `Editando ${personagem.nome}...`, tipo: 'sucesso' });
    
    const formEl = document.querySelector('.grimorio-form');
    if (formEl) formEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleCancelEdit = () => {
    resetForm();
    setMensagem({ texto: 'Edição cancelada.', tipo: 'sucesso' });
  };

  return (
    <div className="medieval-container">
      <div className="atmospheric-background">
        <div className="depth-layer layer-far"></div>
        <div className="depth-layer layer-mid"></div>
        <div className="depth-layer layer-near"></div>
        <div className="fog-overlay fog-1"></div>
        <div className="fog-overlay fog-2"></div>
        <div className="fog-overlay fog-3"></div>
        <div className="vignette-overlay"></div>
      </div>

      {showMagicEffect && (
        <div className="magic-ritual">
          <div className="magic-circle"></div>
          <div className="magic-runes"></div>
          <div className="magic-particles">
            {[...Array(20)].map((_, i) => (
              <div key={i} className={`particle particle-${i + 1}`}></div>
            ))}
          </div>
          <div className="magic-energy-wave"></div>
        </div>
      )}

      <div className="torch-container torch-left-container">
        <div className="torch-holder">
          <div className="torch-wood"></div>
          <div className="torch-metal"></div>
          <div className="flame-container">
            <div className="flame flame-main"></div>
            <div className="flame flame-center"></div>
            <div className="flame flame-inner"></div>
            <div className="flame-sparks"></div>
            <div className="flame-glow"></div>
          </div>
        </div>
      </div>

      <div className="torch-container torch-right-container">
        <div className="torch-holder">
          <div className="torch-wood"></div>
          <div className="torch-metal"></div>
          <div className="flame-container">
            <div className="flame flame-main"></div>
            <div className="flame flame-center"></div>
            <div className="flame flame-inner"></div>
            <div className="flame-sparks"></div>
            <div className="flame-glow"></div>
          </div>
        </div>
      </div>

      <div className="ambient-particles"></div>
      <div className="floating-runes"></div>

      <div className="content-wrapper">
        <header className="grimorio-header">
          <div className="header-ornament top"></div>
          <h1 className="grimorio-title">
            <span className="title-letter">G</span>
            <span className="title-letter">r</span>
            <span className="title-letter">i</span>
            <span className="title-letter">m</span>
            <span className="title-letter">ó</span>
            <span className="title-letter">r</span>
            <span className="title-letter">i</span>
            <span className="title-letter">o</span>
            <span className="title-space"> </span>
            <span className="title-letter">d</span>
            <span className="title-letter">o</span>
            <span className="title-letter">s</span>
            <span className="title-space"> </span>
            <span className="title-letter">H</span>
            <span className="title-letter">e</span>
            <span className="title-letter">r</span>
            <span className="title-letter">ó</span>
            <span className="title-letter">i</span>
            <span className="title-letter">s</span>
          </h1>
          <p className="grimorio-subtitle">Registro Ancestral de Personagens Lendários</p>
          <div className="header-ornament bottom"></div>
        </header>

        {mensagem.texto && (
          <div className={`notification ${mensagem.tipo}`}>
            <span className="notification-icon"></span>
            <span className="notification-text">{mensagem.texto}</span>
          </div>
        )}

        <section className="grimorio-form">
          <div className="form-corner-ornament corner-top-left"></div>
          <div className="form-corner-ornament corner-top-right"></div>
          <div className="form-corner-ornament corner-bottom-left"></div>
          <div className="form-corner-ornament corner-bottom-right"></div>
          
          <h2 className="section-title">
            <span className="title-ornament left"></span>
            {editingId ? 'Atualizar Personagem' : 'Novo Personagem'}
            <span className="title-ornament right"></span>
          </h2>

          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              <div className="form-field">
                <label htmlFor="nome">Nome do Herói</label>
                <input
                  id="nome"
                  type="text"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Digite o nome do personagem"
                  required
                  disabled={loading}
                  className="input-medieval"
                />
              </div>

              <div className="form-field">
                <label htmlFor="classe">Classe</label>
                <select
                  id="classe"
                  value={classe}
                  onChange={(e) => setClasse(e.target.value)}
                  required
                  disabled={loading}
                  className="input-medieval"
                >
                  <option value="">Selecione uma classe</option>
                  {classes.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div className="form-field">
                <label htmlFor="raca">Raça</label>
                <select
                  id="raca"
                  value={raca}
                  onChange={(e) => setRaca(e.target.value)}
                  required
                  disabled={loading}
                  className="input-medieval"
                >
                  <option value="">Selecione uma raça</option>
                  {racas.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

              <div className="form-field">
                <label htmlFor="nivel">Nível</label>
                <input
                  id="nivel"
                  type="number"
                  min="1"
                  max="100"
                  value={nivel}
                  onChange={(e) => setNivel(e.target.value)}
                  disabled={loading}
                  className="input-medieval"
                />
              </div>
            </div>

            <div className="form-field full-width">
              <label htmlFor="historia">História do Personagem</label>
              <textarea
                id="historia"
                value={historia}
                onChange={(e) => setHistoria(e.target.value)}
                placeholder="Escreva a história e as conquistas deste herói..."
                rows="4"
                disabled={loading}
                className="input-medieval"
              />
            </div>

            <div className="form-actions">
              <button type="submit" className="btn-primary" disabled={loading}>
                <span className="btn-text">
                  {loading ? 'Processando...' : editingId ? 'Atualizar Personagem' : 'Registrar Personagem'}
                </span>
              </button>
              {editingId && (
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={handleCancelEdit}
                  disabled={loading}
                >
                  <span className="btn-text">Cancelar Edição</span>
                </button>
              )}
            </div>
          </form>
        </section>

        <section className="taverna-section">
          <div className="form-corner-ornament corner-top-left"></div>
          <div className="form-corner-ornament corner-top-right"></div>
          <div className="form-corner-ornament corner-bottom-left"></div>
          <div className="form-corner-ornament corner-bottom-right"></div>
          
          <div className="section-header">
            <h2 className="section-title">
              <span className="title-ornament left"></span>
              Taverna dos Heróis
              <span className="title-ornament right"></span>
            </h2>
            <div className="hero-counter">
              <span className="counter-label">Heróis Registrados:</span>
              <span className="counter-value">{personagens.length}</span>
            </div>
          </div>

          <div className="search-container">
            <input
              type="text"
              placeholder="Buscar por nome, classe ou raça..."
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="search-input"
            />
          </div>

          {loading && (
            <div className="loading-state">
              <div className="loading-spinner"></div>
              <p>Carregando heróis...</p>
            </div>
          )}

          {!loading && personagens.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon"></div>
              <p>Nenhum herói foi registrado ainda no grimório.</p>
              <p className="empty-subtitle">Comece sua jornada registrando seu primeiro personagem.</p>
            </div>
          ) : (
            <div className="heroes-grid">
              {personagens.map((personagem, index) => (
                <article 
                  key={personagem.id} 
                  className="hero-card"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="card-ambient-glow"></div>
                  <div className="card-shine-overlay"></div>
                  <div className="card-border-glow"></div>
                  
                  <div className="card-header">
                    <h3 className="hero-name">{personagem.nome}</h3>
                    <span className="hero-level">Nível {personagem.nivel}</span>
                  </div>
                  
                  <div className="card-body">
                    <div className="hero-info">
                      <div className="info-item">
                        <span className="info-label">Classe:</span>
                        <span className="info-value">{personagem.classe}</span>
                      </div>
                      <div className="info-item">
                        <span className="info-label">Raça:</span>
                        <span className="info-value">{personagem.raca}</span>
                      </div>
                    </div>
                    
                    {personagem.historia && (
                      <div className="hero-story">
                        <span className="story-label">História:</span>
                        <p className="story-text">{personagem.historia}</p>
                      </div>
                    )}
                  </div>

                  <div className="card-footer">
                    <button
                      onClick={() => handleEdit(personagem)}
                      className="btn-edit"
                      disabled={loading}
                    >
                      <span className="btn-text">Editar</span>
                    </button>
                    <button
                      onClick={() => handleDelete(personagem.id, personagem.nome)}
                      className="btn-delete"
                      disabled={loading}
                    >
                      <span className="btn-text">Remover</span>
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export default App;