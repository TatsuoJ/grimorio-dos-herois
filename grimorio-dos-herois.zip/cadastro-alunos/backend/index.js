// Importação dos módulos necessários
const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();

// Inicializa a aplicação Express
const app = express();
const port = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(express.json());

// Conecta ao banco de dados SQLite
const db = new sqlite3.Database('./bancodedados.db', (err) => {
  if (err) {
    console.error('❌ Erro ao conectar ao banco de dados:', err.message);
  } else {
    console.log('✅ Conectado ao banco de dados SQLite.');
    
    // Cria a tabela 'Personagens' se ela não existir
    db.run(
      `CREATE TABLE IF NOT EXISTS Personagens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        classe TEXT NOT NULL,
        raca TEXT NOT NULL,
        nivel INTEGER DEFAULT 1,
        historia TEXT
      )`,
      (err2) => {
        if (err2) {
          console.error('❌ Erro ao criar tabela:', err2.message);
        } else {
          console.log("✅ Tabela 'Personagens' verificada/criada com sucesso.");
        }
      }
    );
  }
});

// --- ROTAS DA API ---

// Rota para LISTAR todos os personagens (Método GET)
app.get('/personagens', (req, res) => {
  const { busca } = req.query;
  
  let sql = 'SELECT * FROM Personagens';
  let params = [];
  
  if (busca) {
    sql += ' WHERE nome LIKE ? OR classe LIKE ? OR raca LIKE ?';
    const termoBusca = `%${busca}%`;
    params = [termoBusca, termoBusca, termoBusca];
  }
  
  sql += ' ORDER BY nome';
  
  db.all(sql, params, (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar personagens: ' + err.message });
    }
    res.json(rows);
  });
});

// Rota para CADASTRAR um novo personagem (Método POST)
app.post('/personagens', (req, res) => {
  const { nome, classe, raca, nivel, historia } = req.body;
  
  // Validações
  if (!nome) return res.status(400).json({ error: 'O campo "nome" é obrigatório.' });
  if (!classe) return res.status(400).json({ error: 'O campo "classe" é obrigatório.' });
  if (!raca) return res.status(400).json({ error: 'O campo "raça" é obrigatório.' });
  
  const nivelFinal = nivel && nivel > 0 ? nivel : 1;
  
  const sql = 'INSERT INTO Personagens (nome, classe, raca, nivel, historia) VALUES (?, ?, ?, ?, ?)';
  
  db.run(sql, [nome, classe, raca, nivelFinal, historia || null], function (err) {
    if (err) {
      return res.status(500).json({ error: 'Erro ao cadastrar personagem: ' + err.message });
    }
    res.status(201).json({ 
      id: this.lastID, 
      nome, 
      classe, 
      raca, 
      nivel: nivelFinal, 
      historia: historia || null 
    });
  });
});

// Rota para DELETAR um personagem pelo ID (Método DELETE)
app.delete('/personagens/:id', (req, res) => {
  const { id } = req.params;
  
  const sql = 'DELETE FROM Personagens WHERE id = ?';
  
  db.run(sql, [id], function (err) {
    if (err) {
      return res.status(500).json({ error: 'Erro ao deletar personagem: ' + err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Personagem não encontrado.' });
    }
    res.json({ message: 'Personagem removido com sucesso!' });
  });
});

// Rota para ATUALIZAR um personagem pelo ID (Método PUT)
app.put('/personagens/:id', (req, res) => {
  const { id } = req.params;
  const { nome, classe, raca, nivel, historia } = req.body;
  
  if (!nome && !classe && !raca && !nivel && !historia) {
    return res.status(400).json({ 
      error: 'Forneça ao menos um campo para atualizar (nome, classe, raca, nivel, historia).' 
    });
  }
  
  const fieldsToUpdate = [];
  const values = [];
  
  if (nome) {
    fieldsToUpdate.push('nome = ?');
    values.push(nome);
  }
  if (classe) {
    fieldsToUpdate.push('classe = ?');
    values.push(classe);
  }
  if (raca) {
    fieldsToUpdate.push('raca = ?');
    values.push(raca);
  }
  if (nivel !== undefined) {
    fieldsToUpdate.push('nivel = ?');
    values.push(nivel);
  }
  if (historia !== undefined) {
    fieldsToUpdate.push('historia = ?');
    values.push(historia);
  }
  
  values.push(id);
  
  const sql = `UPDATE Personagens SET ${fieldsToUpdate.join(', ')} WHERE id = ?`;
  
  db.run(sql, values, function (err) {
    if (err) {
      return res.status(500).json({ error: 'Erro ao atualizar personagem: ' + err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Personagem não encontrado para atualização.' });
    }
    res.json({ message: 'Personagem atualizado com sucesso!', changes: this.changes });
  });
});

// Rota para obter estatísticas (EXTRA)
app.get('/estatisticas', (req, res) => {
  db.get('SELECT COUNT(*) as total FROM Personagens', [], (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    db.all(
      'SELECT classe, COUNT(*) as quantidade FROM Personagens GROUP BY classe',
      [],
      (err2, classes) => {
        if (err2) {
          return res.status(500).json({ error: err2.message });
        }
        res.json({ 
          totalPersonagens: row.total,
          porClasse: classes 
        });
      }
    );
  });
});

// Inicia o servidor
app.listen(port, () => {
  console.log(`🗡️  Servidor do Grimório rodando em http://localhost:${port}`);
});

// Encerra o DB com segurança ao finalizar o processo
process.on('SIGINT', () => {
  db.close(() => {
    console.log('🔒 Conexão com SQLite encerrada.');
    process.exit(0);
  });
});